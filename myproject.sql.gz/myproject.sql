--
-- Database: `myproject`
--

-- --------------------------------------------------------

--
-- Table structure for table `game`
--

CREATE TABLE `game` (
  `GID` varchar(30) NOT NULL,
  `GName` varchar(20) NOT NULL,
  `GType` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `game`
--

INSERT INTO `game` (`GID`, `GName`, `GType`) VALUES
('', '', ''),
('20130194', 'Mohamed K Amer', 'Student'),
('525', 'IGI', 'Action');

-- --------------------------------------------------------

--
-- Table structure for table `register_user_info`
--

CREATE TABLE `register_user_info` (
  `User_Name` varchar(30) NOT NULL,
  `User_ID` varchar(30) NOT NULL,
  `Password` varchar(30) NOT NULL,
  `User_Type` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `register_user_info`
--

INSERT INTO `register_user_info` (`User_Name`, `User_ID`, `Password`, `User_Type`) VALUES
('Hany', '11111', '11111', 'Teacher'),
('Ahmed Hosny', '20100894', '123456789', 'Teacher'),
('omnia mohamed', '20102006', '2234660', 'Student'),
('Maher', '20130029', '12345', 'Student'),
('Mohamed', '20130194', '2234660', 'Teacher'),
('Eslam', '20140058', '444444', 'Teacher'),
('Omnia', '20140071', '123456', 'Student'),
('Raja', '20140118', '666666', 'Student'),
('mohamed adel', '20140331', '12345', 'Student'),
('Foda', '20140555', '2234660', 'Teacher'),
('Admin', '20160194', '55555', 'Teacher'),
('Fatma', '555555', '555555', 'Student'),
('Khaled', '6666', '2055', 'Teacher'),
('Amer', '777666', '777777', 'Teacher'),
('Hoda', '77777', '7777777', 'Teacher'),
('Mama', 'Mama', 'Mama', 'Teacher');

-- --------------------------------------------------------

--
-- Table structure for table `user_account`
--

CREATE TABLE `user_account` (
  `UserName` varchar(30) NOT NULL,
  `Password` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_account`
--

INSERT INTO `user_account` (`UserName`, `Password`) VALUES
('Khaled', '2055'),
('Hamo', '000000'),
('Hany', '11111'),
('Hoda', '7777777'),
('Fatma', '555555'),
('Amer', '777777'),
('Ahmed Hosny', '123456789'),
('omnia mohamed', '2234660'),
('Maher', '12345'),
('Mohamed', '2234660'),
('Omnia', '123456'),
('Raja', '666666'),
('mohamed adel', '12345'),
('Admin', '55555'),
('Foda', '2234660'),
('Eslam', '444444'),
('Mama', 'Mama'),
('Mohamed K Amer', '55555');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `game`
--
ALTER TABLE `game`
  ADD PRIMARY KEY (`GID`);

--
-- Indexes for table `register_user_info`
--
ALTER TABLE `register_user_info`
  ADD PRIMARY KEY (`User_ID`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
